#!/system/bin/sh

#Modules_Dir=/data/adb/modules
MODPATH=$Modules_Dir/Automatic_brick_rescue
START_LOG=$MODPATH/Number_of_starts.log
LOG=$MODPATH/Number_of_brick_rescue.log
[[ -f $LOG ]] && Number_of_brick_rescue=`cat $LOG`
Module_XinXi=$MODPATH/module.prop
export PATH="/sbin:/system/sbin:/product/bin:/apex/com.android.runtime/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin"

if [[ ! -f $START_LOG ]]; then
   echo 0 >"$START_LOG"
   Frequency2=0
else
   Frequency=`cat $START_LOG`
   Frequency2="$((Frequency+1))"
   echo "$Frequency2" >"$START_LOG"
fi
   if [[ $Frequency2 -eq 2 ]]; then
      rm -rf /data/system/package_cache/*
      echo 'setenforce 0' >"$MODPATH/post-fs-data.sh"
      reboot
   elif [[ $Frequency2 -ge 3 ]]; then
      for i in `ls $Modules_Dir`; do
         [[ "$i" = "Automatic_brick_rescue" ]] && continue
         touch "$Modules_Dir/$i/disable"
      done
      rm -f "$START_LOG"
      reboot recovery
   fi
      sleep 1.5m
      if [[ `getprop init.svc.bootanim` = "stopped" ]]; then
         rm -f "$START_LOG" "$MODPATH/post-fs-data.sh"
         if [[ -f $LOG ]]; then
            sed -i "/^description=/c\description=用途：当刷入一些模块导致无法正常开机，自动触发已设置的自动救砖操作方式：如果在重启2次后未成功开机自动自动清除系统包名缓存和关闭SELinux尝试一次开机操作，如果再无限重启3次后未开机强制自动救砖重启到recovery，正常启动等待1.5分钟后没有开机自动禁用所有模块，已为您自动救砖：$Number_of_brick_rescue次。" "$Module_XinXi"
         fi
      else
         if [[ ! -f $LOG ]]; then
            echo "1" >$LOG
         else
            p=$((Number_of_brick_rescue+1))
            echo "$p" >$LOG
         fi
            for i in `ls $Modules_Dir`; do
               touch "$Modules_Dir/$i/disable"
            done
            reboot
      fi

