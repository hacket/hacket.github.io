#!/system/bin/sh
#特别鸣谢Magisk提供服务支持：by topjohnwu

Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [[ "$i" = "$MODID" ]] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    Reserve
    reboot
}

Statistics() {
    if [[ ! -f $LOG ]]; then
        echo "1" >$LOG
    else
        Number_of_brick_rescue=`cat $LOG`
        p="$(expr $Number_of_brick_rescue + 1)"
        echo "$p" >$LOG
    fi
}

bmd(){
cat  ${0%/*}/白名单.conf | sed '/^[[:space:]]*$/d;/^#/d'
}

function Reserve(){
for i in $(bmd);do 
	rm /data/adb/modules/"$i"/disable &>/dev/null
done
}

rmlog(){
    # Initialize the counter variable
    counter=0
    # Set the number of times to loop
    num_loop=40

while [[ -z $(dumpsys window policy | grep mIsShowing | grep false) ]] || [[$counter -le $num_loop ]] ;do
	sleep 3
	((counter++))
	#调试用的echo "$(date '+%T')正在循环……" >>$MODDIR/log
done
   rm -f $START_LOG
   #调试用的echo "$(date '+%T')已经删除日志" >>$MODDIR/log
exit 0
}


MODDIR=${0%/*}
MODID=${MODDIR##*/}
Module_XinXi=$MODDIR/module.prop
START_LOG=$MODDIR/Number_of_starts.log
LOG=$MODDIR/Number_of_brick_rescue.log
VERSION=$MODDIR/now_version
now_version=$(getprop ro.system.build.version.incremental)


    mv -f $Module_XinXi.bak $Module_XinXi && sed -i '34d' "$0"
    rmlog &
#这里下面最后“2”就是删重启记录和卡开机时执行救砖的时间
        sleep 2m

        if [[ `getprop init.svc.bootanim` = "stopped" ]]; then
        rm -f "$START_LOG"

        if [[ -f $LOG ]]; then
            Number_of_brick_rescue=`cat $LOG`
            sed -i "/^description=/c description=[已启用]自动救砖条件：系统连续重启到3次或卡在开机界面2分钟(每次OTA升级系统时将自动延长时间至30分钟)，将禁用所有模块。若再不开机会执行APP解冻救砖模式再开机。模块目录/白名单.conf里可以添加救砖跳过的白名单。已为您自动救砖：$Number_of_brick_rescue次。" "$Module_XinXi"
        echo "$now_version" > "$VERSION"   
        fi
    else
        Statistics
        Disable_All_Modules       
    fi

